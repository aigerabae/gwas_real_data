These are helper scripts used in the analysis p2. All R scripts are from https://github.com/MareesAT/GWA_tutorial and python scripts are my own 
